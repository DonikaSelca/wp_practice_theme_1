<?php
  function practice_theme_1_metaboxes_admin_scripts(){
    global $pagenow;
    if($pagenow !== 'post.php') return;
    wp_enqueue_script( 'practice_theme_1-metaboxes-admin-scripts', plugins_url(
    'practice_theme_1-metaboxes/dist/assets/js/admin.js'), array('jquery'), '1.0.0' , true);

    wp_enqueue_style( 'practice_theme_1-metaboxes-admin-stylesheet', plugins_url(
    'practice_theme_1-metaboxes/dist/assets/css/admin.css'), array(), '1.0.0', 'all');
  }
  add_action( 'admin_enqueue_scripts', 'practice_theme_1_metaboxes_admin_scripts');
?>
