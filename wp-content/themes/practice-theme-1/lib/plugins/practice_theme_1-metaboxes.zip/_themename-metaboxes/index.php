<?php
/*
Plugin Name: practice_theme_1 metaboxes
Plugin URI:
Description: Adding Metaboxes for practice_theme_1
Version: 1.0.0
Author: Donika Selca
Author URI:
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Test Domain: practice_theme_1-metaboxes
Domain Path: /languages
*/
if(!defined('WPINC')){
  die;
}
include_once('includes/metaboxes.php');
include_once('includes/enqueue-assets.php');
?>
