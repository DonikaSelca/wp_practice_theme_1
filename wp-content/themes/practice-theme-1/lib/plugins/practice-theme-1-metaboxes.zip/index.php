<?php
/*
Plugin Name: practice-theme-1 metaboxes
Plugin URI:
Description: Adding Metaboxes for practice-theme-1
Version: 1.0.0
Author: Donika Selca
Author URI:
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Test Domain: practice-theme-1-metaboxes
Domain Path: /languages
*/
if(!defined('WPINC')){
  die;
}
include_once('includes/metaboxes.php');
include_once('includes/enqueue-assets.php');
?>
