<?php
/*
Plugin Name: practice-theme-1 shortcodes
Plugin URI:
Description: Adding Shortcodes for practice-theme-1
Version: 1.0.0
Author: Donika Selca
Author URI:
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Test Domain: practice-theme-1-shortcodes
Domain Path: /languages
*/
  if(!defined('WPINC')){
    die;
  }

  function practice-theme-1_shortcodes_init(){
    include_once('includes/shortcodes/button/button.php');
    include_once('includes/shortcodes/slider/slider.php');
  }

  add_action('init', 'practice-theme-1_shortcodes_init');

  include_once('includes/enqueue-assets.php');
?>
