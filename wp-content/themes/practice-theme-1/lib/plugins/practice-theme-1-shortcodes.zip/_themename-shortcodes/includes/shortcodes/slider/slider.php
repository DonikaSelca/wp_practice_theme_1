<?php
  function practice-theme-1_slider($atts = [], $content = null, $tag = ''){
    extract(shortcode_atts([
      'autoplay' => false,
      'arrows' => false
    ], $atts, $tag));
    $output = '<div data-slick=\'{"autoplay":' . boolval($autoplay) . ', "arrows":' . boolval($arrows) . '}\'>';
    $output .= '</div>';
    return $output;
    console.log($output);
  }
  console.log('plugin change test');
  add_action('practice-theme-1_slider', 'practice-theme-1_slider')
?>
