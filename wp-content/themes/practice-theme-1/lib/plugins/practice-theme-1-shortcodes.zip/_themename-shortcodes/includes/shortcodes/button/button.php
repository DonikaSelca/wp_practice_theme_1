<?php
  function practice-theme-1_button($atts = [], $content = null, $tag = ''){
    extract(shortcode_atts([
      'color' => 'red',
      'text' => 'Button'
    ], $atts, $tag));
    return '<button class="practice-theme-1_button style="background-color:' . esc_attr($color) . '">' . do_shortcode($content) . '</button>';
  }

  add_shortcode('practice-theme-1_button', 'practice-theme-1_button');
?>
