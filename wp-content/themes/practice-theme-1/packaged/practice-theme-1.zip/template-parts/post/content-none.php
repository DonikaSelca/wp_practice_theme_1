<p><?php echo apply_filters('practice-theme-1_no_posts_text', esc_html__('Sorry, there are no posts that match your criteria.', 'practice-theme-1')); ?></p>
<!-- Hooking into filter allows other developers to choose what text is displayed ...connects to child-theme. -->
