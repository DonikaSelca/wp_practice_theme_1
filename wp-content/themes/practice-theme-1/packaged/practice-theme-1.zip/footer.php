    </div>
    <footer id="footer" role="contentinfo">
      <?php get_template_part('template-parts/footer/widgets'); ?>
  <!-- Places the widget and site info template parts into footer -->
      <?php get_template_part('template-parts/footer/site-info'); ?>
    </footer>
    <?php wp_footer() ?>
  </body>
</html>
