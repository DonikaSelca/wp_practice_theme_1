<aside role="complementary">
  <!-- Displays the sidebar -->
  <!--  Displays by calling the function dynamic_sidebar with the ID we gave in lib/sidebars.php as argument. -->
  <?php dynamic_sidebar('primary-sidebar'); ?>
</aside>
