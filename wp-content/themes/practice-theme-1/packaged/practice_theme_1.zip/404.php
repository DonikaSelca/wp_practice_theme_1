<?php get_header(); ?>
<!-- Displays 404 Not Found page - Also establishes main content width depending on whether there is a primary sidebar active -->
  <div class="o-container u-margin-bottom-40">
    <div class="o-row">
      <div class="o-row__column o-row__column--span-12">
        <main role="main">
          <h3><?php esc_html_e("We've got nothing, try searching!", 'practice_theme_1') ?></h3>
        </main>
      </div>
    </div>
  </div>
<?php get_footer(); ?>
