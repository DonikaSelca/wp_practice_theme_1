<p><?php echo apply_filters('practice_theme_1_no_posts_text', esc_html__('Sorry, there are no posts that match your criteria.', 'practice_theme_1')); ?></p>
<!-- Hooking into filter allows other developers to choose what text is displayed ...connects to child-theme. -->
